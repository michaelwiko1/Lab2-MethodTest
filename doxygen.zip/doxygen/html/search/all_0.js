var searchData=
[
  ['board_0',['Board',['../class_board.html',1,'']]],
  ['boardobject_1',['BoardObject',['../class_board_object.html',1,'']]]
];
